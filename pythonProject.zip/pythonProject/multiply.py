def mul_num(num1,num2):
    num=(num1*num2)
    return num
num1=int(input("enter 1st value:"))
num2=int(input("enter 2nd value:"))
print("Display the result:",mul_num(num1,num2))