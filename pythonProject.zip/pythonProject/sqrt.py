n=int(input("enter the Squareroot number:"))
sqrt=n**0.5
print("Display the Squareroot :",sqrt)