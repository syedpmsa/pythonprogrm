# python program to add two numbers
# take numbers
num1 = 4
num2 = 5
# add two numbers
sum = num1+num2
#display two addition Result
print("the sum of result:",sum)
print("{0}+{1}={2}".format(num1,num2,sum))
