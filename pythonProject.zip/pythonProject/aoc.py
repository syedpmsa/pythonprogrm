#r=14
#ac=3.14*r*r
#print("Dispay the area of circal:",ac)

def ac(r):
    pi=3.14
    return pi*(r*r)
print("the result is:",ac(5))
