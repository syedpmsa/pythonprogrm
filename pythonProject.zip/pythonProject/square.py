n=int(input("enter the nuber :"))
s=n**2
print("display the result:",s)