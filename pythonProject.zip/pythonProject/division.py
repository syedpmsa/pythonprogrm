#//def div_num(num1,num2):
   #div=num1/num2
    #return div
#num1=int(input("Enter the 1st number :"))
#num2=int(input("enter the 2st number :"))
#print("Display the Result :",div_num(num1,num2))

num1=int(input("Enter the 1st number :"))
num2=int(input("enter the 2st number :"))
div = num1/num2
print("Dispay the result : {0}/{1}={2}".format(num1,num2,div))