base=int(input("enter the base of triangal:"))
high=int(input("enter the hight of trigale: "))
tri=1/2*base*high
print("Dispay the triganle :",tri)