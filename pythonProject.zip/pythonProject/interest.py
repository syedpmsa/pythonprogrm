P = float(input('Enter principal amount: '))
R = float(input('Enter the interest rate: '))
T = float(input('Enter time: '))
st=(P*R*T)/100
print("play interest amount",st)
print("total amount of :",(P+st))