def avg_num(num1,num2):
    avg=num1+num2/2
    return avg
num1=int(input("enter 1st number:"))
num2=int(input("enter 2nd number:"))
print("Display the Result:",avg_num(num1,num2))