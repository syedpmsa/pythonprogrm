#take input form user
num1=int(input("enter 1st number:"))
num2=int(input("enter 2nd number:"))
#subtract two numbers
sub=num1-num2
#Display the subtract Result
print("{0}-{1}={2}".format(num1,num2,sub))